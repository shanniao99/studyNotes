export default {
	state:{
		name:"我的"
	},
	getters:{},
	mutations:{},	
	actions:{}
}