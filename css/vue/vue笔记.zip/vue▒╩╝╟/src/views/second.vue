<template>
	<div>页面二---{{x}}--{{y}}</div>
</template>

<script>
	export default{
		props:["x","y"]
	}
</script>

<style>
</style>
